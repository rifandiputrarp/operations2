<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MasterBidangUsaha extends Model
{
    use HasFactory;

    protected $table = 'master_bidang_usaha';
}
